buddhist_dict = [
    {
        "tag": "软件",
        "img": "",
        "name": "闪豆多平台视频批量下载器",
        "short_describe": "支持下载60多个平台视频的下载器",
        "describe": "闪豆视频下载器是一款PC"
                    "端网页流媒体获取工具，\n工具实现的原理和登录网站看视频是一样的，"
                    "用户能看到什么清晰度的视频，就能缓存对应的视频，\n"
                    "同样的会员视频需要登录对应的账号才能下载，解析下载过程都非常简单，\n"
                    "界面清爽简约，下载速度快。",
        "guide": "",
        "download_page_url": "https://www.lanzoui.com/b015c0ksh",
    },
    {
        "tag": "软件",
        "img": "https://www.snipaste.com/img/logo.svg",
        "name": "Windows Snipaste截图工具 v2.7.3 绿色版",
        "short_describe": "一个简单但强大的截图工具,可以将剪贴板里的文字或者颜色信息转化为图片窗口。",
        "describe": "免费无广告,安装成功后快捷键截图,任务栏可打开软件;\n"
                    "强大的截图,像素级的鼠标移动控制、截图范围控制,取色器;\n"
                    "支持将剪贴板中的以下内容转为图片;\n"
                    "支持图像文件：PNG, JPG, BMP, ICO, GIF 等;\n"
                    "自带64/86位安装;\n"
                    "帮助页,详细的教程,快捷键,高级设置等。",
        "guide": "",
        "download_page_url": "https://afengkeji.lanzoum.com/ig5T0012gntc",
    },
    {
        "tag": "软件",
        "img": "https://mathewsachin.github.io/Captura/assets/favicon.ico",
        "name": "Windows Captura屏幕录制_v8.0.0",
        "short_describe": "一款开源的Windows录屏工具。支持运行在所有常见的Windows操作系统上。使用起来简单便捷。小巧、多功能，又有着丰富自定义功能的小工具。",
        "describe": "无需安装，附带FFmpeg版本\n"
                    "能够将屏幕上的任意区域、窗口录制成视频\n"
                    "可以选择是否显示鼠标、记录鼠标点击、键盘按键、声音\n"
                    "支持选择录制区域，视频编码器，帧率及质量",
        "guide": "",
        "download_page_url": "https://afengkeji.lanzoum.com/ieKeh0gxdt3a",
    },
{
        "tag": "图书",
        "img": "https://www.book123.info/logo.png",
        "name": "无名图书",
        "short_describe": "一个免费的电子图书下载站。",
        "describe": "",
        "guide": "",
        "download_page_url": "https://www.book123.info/",
    },
]
