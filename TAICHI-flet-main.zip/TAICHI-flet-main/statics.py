import flet
from flet import Image, Container

TAICHI = Image(src="imgs/taichi.svg", width=40, height=40, fit="cover")
BIG_TAICHI = Image(src="imgs/taichi.svg", width=200, height=200, fit="cover")
CLOUD = Image(src="imgs/cloud.svg", fit="cover")

GONGZHONGHAO = Container()
